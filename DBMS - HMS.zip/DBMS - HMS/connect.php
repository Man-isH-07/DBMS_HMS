<?php
 
$conn = mysqli_connect('localhost', 'root' ,'', 'DBMS_secB');

if(!$conn)
{
    echo 'Error';
}

?>